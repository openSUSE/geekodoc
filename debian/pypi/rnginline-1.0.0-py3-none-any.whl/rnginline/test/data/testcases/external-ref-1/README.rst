This testcase verifies simple inclusion of an external grammar with an
``<externalRef>`` element.
